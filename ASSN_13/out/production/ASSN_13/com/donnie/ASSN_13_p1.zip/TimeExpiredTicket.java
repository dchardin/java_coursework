package com.donnie;

public class TimeExpiredTicket extends Ticket {

    private double charge;

    public TimeExpiredTicket(String tag, String make, String model, String color, double charge) {
        super(tag, make, model, color);
        this.charge = charge;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge = charge;
    }
}
