package com.donnie;

public class HandicappedTicket extends Ticket {

    private double charge;

    public HandicappedTicket(String tag, String make, String model, String color, double charge) {
        super(tag, make, model, color);
        this.charge = charge;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge = charge;
    }
}
