package com.donnie;

public class FireLaneTicket extends Ticket {

    private double charge;

    public FireLaneTicket(String tag, String make, String model, String color, double charge) {
        super(tag, make, model, color);
        this.charge = charge;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge = charge;
    }
}
